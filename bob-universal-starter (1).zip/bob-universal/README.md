# Bob Universal (starter project)

Bob Universal is the shared source project for three planned ways to use Bob:

1. **Termux on Android** — run the Python server locally and open the interface in a mobile browser.
2. **Public website** — deploy a properly hardened multi-user backend before inviting public users.
3. **Android app** — package the web experience in an Android app after the backend URL and app identity are decided.

## Run on Termux

Install Termux from a trusted source, then place this project folder in Termux storage. In Termux, change to this folder and run:

```bash
bash install.sh
bash start.sh
```

Open `http://127.0.0.1:8000` in your phone's browser. Keep Termux running while using Bob. Stop it with Ctrl+C.

### Compatibility note

Bob currently imports NumPy and scikit-learn. Their availability varies by Python version and Android/Termux architecture. If `bash install.sh` fails while building scikit-learn, save the full error output; don't assume installation succeeded. We must test a supported Termux/Python combination or refactor Bob's ML code before claiming it works on every phone.

## Public deployment warning

**Do not expose this prototype directly to the public internet.** The current server starts one shared Bob process and Bob's memory/data may be shared between visitors. Before public release, implement per-user sessions and isolated state, authentication if appropriate, rate limits, HTTPS, safe persistence, and secret management. Never commit API keys or personal memory files.

## Android app status

This repository is not yet an installable APK. An APK must be built and signed using Android tooling, and it needs a chosen backend URL. The app should not point at `127.0.0.1` for a remote service because that address means the user's own phone.

## GitHub publishing

Review files before publishing. Remove any API keys, personal data, private memory files, generated logs, and local caches. Then create a GitHub repository and push this folder.
