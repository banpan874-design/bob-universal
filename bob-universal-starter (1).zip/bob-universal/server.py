#!/usr/bin/env python3
"""
Bob Web Server - runs the unmodified terminal chatbot bob.py on a localhost website.

How it works:
  - Starts bob.py once as a subprocess (python -u, unbuffered I/O).
  - Every message from the browser is written to Bob's stdin (that's his input("You: ")).
  - Everything Bob prints is captured from stdout and returned to the browser.
  - Prompts (anything printed without a newline, like 'You: ' or 'Rate: g = good...: ')
    are shown in the chat so the user knows Bob is waiting for a follow-up answer.

Run:
  python3 server.py            # then open http://localhost:8000
  PORT=8080 python3 server.py  # pick another port
"""

import http.server
import json
import os
import re
import select
import socketserver
import subprocess
import sys
import threading
import time
import traceback

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BOB_PATH = os.path.join(BASE_DIR, "bob.py")
PORT = int(os.environ.get("PORT", "8000"))
HOST = os.environ.get("HOST", "127.0.0.1")
MAX_BODY_BYTES = 16_384

# Bob asks follow-up questions with prompts like these (printed without a newline)
PROMPT_RE = re.compile(r"(?:You: |Enter = skip: )\s*$")


class BobProcess:
    """Owns one live bob.py subprocess and talks to it line by line."""

    def __init__(self):
        self.proc = None
        self.lock = threading.Lock()
        self.pending = ""  # bytes read but not yet split into full lines

    def start(self):
        if self.proc and self.proc.poll() is None:
            return
        self.pending = ""
        self.proc = subprocess.Popen(
            [sys.executable, "-u", BOB_PATH],
            cwd=BASE_DIR,                     # Bob's memory/JSON files live beside bob.py
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,         # show crashes/errors in chat instead of dying silently
            bufsize=0,
        )

    def _read_available(self, hard_timeout=90.0):
        """Read Bob's stdout until his turn is over.

        Bob ALWAYS ends a turn by printing a prompt without a newline and
        blocking on input(): either 'You: ' (main loop, teach, weather city)
        or 'Enter = skip: ' (feedback rating). So instead of guessing with
        idle timeouts (slow network fetches stay silent for seconds), we
        read until we see one of those exact terminators.
        """
        fd = self.proc.stdout.fileno()
        out = b""
        start = time.time()
        while True:
            if time.time() - start > hard_timeout:
                break
            if self.proc.poll() is not None:
                try:
                    out += os.read(fd, 65536)
                except OSError:
                    pass
                break
            r, _, _ = select.select([fd], [], [], 0.5)
            if not r:
                continue  # Bob is working (e.g. fetching the web) -> keep waiting
            try:
                chunk = os.read(fd, 65536)
            except OSError:
                break
            if not chunk:
                break
            out += chunk
            tail = out[-32:].decode("utf-8", errors="replace")
            if tail.endswith("You: ") or tail.endswith("Enter = skip: "):
                break  # Bob is now blocked waiting for the user's next input
        return out.decode("utf-8", errors="replace")

    def ask(self, message, first=False):
        """Send one user message to Bob and collect his full reply. Thread-safe."""
        with self.lock:
            self.start()
            if not first:
                try:
                    self.proc.stdin.write((message + "\n").encode("utf-8"))
                    self.proc.stdin.flush()
                except (BrokenPipeError, OSError):
                    self.start()  # Bob died; restart and retry once
                    self._read_available()
                    self.proc.stdin.write((message + "\n").encode("utf-8"))
                    self.proc.stdin.flush()
            text = self._read_available()
            if self.proc.poll() is not None and not text.strip():
                text = "Bob: (Bob exited. Send any message to restart him.)"
            return self._to_messages(text)

    @staticmethod
    def _to_messages(text):
        """Split Bob's raw output into chat bubbles; trailing prompt becomes its own hint."""
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        # A bare 'You: ' prompt can end up glued onto the start of the next reply
        text = re.sub(r"You: (?=\S)", "You:\n", text)
        messages = []
        for line in text.split("\n"):
            if line.strip():
                messages.append(line.rstrip())
        return messages


BOB = BobProcess()


class Handler(http.server.BaseHTTPRequestHandler):
    """Small API server: deliberately serves only the public chat page, never project files."""

    server_version = "BobWeb/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("[bob-web] %s\n" % (fmt % args))

    def do_GET(self):
        if self.path not in ("/", "/index.html"):
            return self._json({"error": "not found"}, 404)
        try:
            with open(os.path.join(BASE_DIR, "index.html"), "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(data)
        except OSError:
            self._json({"error": "chat page unavailable"}, 500)

    def do_POST(self):
        if self.path != "/api/chat":
            return self._json({"error": "not found"}, 404)
        if self.headers.get_content_type() != "application/json":
            return self._json({"error": "content-type must be application/json"}, 415)
        try:
            raw_length = self.headers.get("Content-Length", "0")
            length = int(raw_length)
            if length < 0 or length > MAX_BODY_BYTES:
                return self._json({"error": "request body too large"}, 413)
            body = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(body, dict):
                raise ValueError("JSON body must be an object")
            message = body.get("message", "")
            if not isinstance(message, str):
                raise ValueError("message must be text")
            message = message.strip()
            if len(message) > 4000:
                return self._json({"error": "message is too long (maximum 4000 characters)"}, 413)
            first = body.get("first", False) is True
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            return self._json({"error": f"bad request: {exc}"}, 400)
        try:
            replies = BOB.ask(message, first=first)
        except Exception:
            # Avoid exposing filesystem paths or internal exception details to clients.
            traceback.print_exc(file=sys.stderr)
            replies = ["Bob: Sorry, something went wrong. Please try again."]
        return self._json({"replies": replies})

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    if not os.path.exists(BOB_PATH):
        print(f"ERROR: bob.py not found next to server.py ({BOB_PATH})")
        sys.exit(1)
    BOB.start()
    print(f"Bob is listening on {HOST}:{PORT}")
    if HOST != "127.0.0.1":
        print("WARNING: This server is reachable on the network. Do not expose it publicly without authentication, HTTPS, per-user sessions, and persistent-storage planning.")
    print("Press Ctrl+C to stop.")
    with Server((HOST, PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
    if BOB.proc:
        BOB.proc.terminate()


if __name__ == "__main__":
    main()
