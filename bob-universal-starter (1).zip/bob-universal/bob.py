# Bob: a tiny chatbot that LEARNS which kind of message you sent.
# He also remembers you, looks facts up, does math, checks live weather, currency rates
# and news headlines from free sources, reads pages, files, and PDFs (pip install pypdf), searches the web with sources,
# makes and reads QR codes, and learns from your feedback.
# pip install scikit-learn pypdf   (pypdf is only needed for reading PDFs)
# Search keys (no terminal needed): type  web setkey <your key>  inside Bob, then  web status  to test them.
import ast, datetime, difflib, io, json, operator, os, random, re, shlex, shutil, struct, subprocess, zlib
from collections import namedtuple
import urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor
import xml.etree.ElementTree as ET
import numpy as np
from html.parser import HTMLParser
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.linear_model import LogisticRegression

CONFIDENCE = 0.30  # below this, Bob admits he isn't sure

# If someone talks about hurting themselves, Bob doesn't joke or guess. He points to real help.
CRISIS = re.compile(r"kill myself|want to die|end my life|suicid|hurt myself|harm myself|"
                    r"(?:don'?t|do not) want to (?:live|be alive)|no reason to live|better off dead")
CRISIS_REPLY = ("Bob: I'm really sorry you're hurting. I'm only a small program, and you deserve real support "
                "right now. If you might act on these thoughts, please call your local emergency number or a "
                "crisis line, or tell someone near you right away. You can find crisis lines by country at "
                "findahelpline.com. You matter, and I'm glad you told me.")

# Chat shorthand Bob expands before he reads a message
SLANG = {"thx": "thanks", "thnx": "thanks", "tnx": "thanks", "ty": "thank you", "tysm": "thank you so much",
         "gn": "good night", "goodnight": "good night", "gm": "good morning", "u": "you", "ur": "your",
         "r": "are", "pls": "please", "plz": "please", "thankyou": "thank you"}
STOPWORDS = {"the", "a", "an", "is", "are", "was", "were", "of", "to", "in", "on", "and", "or", "it", "i", "me",
             "my", "you", "what", "who", "how", "when", "where", "why", "tell", "about", "do", "does",
             "please", "bob", "this", "that"}
SECOND_PERSON = {"you", "your", "ur", "u", "bob", "yourself", "youre"}

# Words and phrases Bob's tools rely on (defined here so his spell-fixer knows them too)
WORD_OPS = [("divided by", "/"), ("multiplied by", "*"), ("to the power of", "**"),
            ("times", "*"), ("plus", "+"), ("minus", "-"), ("over", "/")]

FILLER = {"what", "is", "whats", "what's", "calculate", "compute", "solve", "how", "much",
          "equals", "the", "result", "please", "bob", "tell", "me", "answer", "to", "of",
          "and", "does", "do", "are", "a", "can", "you"}

# Live things Bob has no free source for, so he says so instead of guessing.
UNSUPPORTED_LIVE = ["stock price", "live score", "traffic", "flight status",
                    "bitcoin price", "crypto price", "right now"]

# =====================================================================
# 1. DATA: example messages for each category. More examples = smarter Bob.
# =====================================================================
data = {
    "greeting": ["hi", "hello", "hey bob", "good morning", "yo", "hey there", "hi bob", "howdy",
                 "good evening", "good afternoon", "what's up", "sup", "greetings", "hola", "hey",
                 "hello bob", "hey hey", "good day", "howdy partner", "hi friend", "heya",
                 "greetings bob", "well hello", "morning everyone", "mornin", "top of the morning"],
    "feeling": ["how are you", "how are you doing", "how is it going", "you good bob",
                "how have you been", "are you ok", "how do you feel", "how's life",
                "how are things going", "how is everything", "how have you been lately",
                "how do you do", "everything ok with you", "are you doing well", "you doing fine",
                "you alright bob", "are you feeling well", "are you okay today"],
    "name": ["what is your name", "who are you", "tell me your name", "are you bob",
             "what should i call you", "introduce yourself", "your name", "what is your name bob",
             "tell me who you are", "may i know your name", "your name please",
             "what are you called", "what's your name"],
    "tired": ["i am tired", "long day", "i need sleep", "so much work today", "i am exhausted",
              "i'm sleepy", "i need a nap", "i worked all day", "i'm beat", "so tired",
              "what a long day", "this day was tough", "i am wiped out", "im wiped out",
              "so drained", "my eyes are closing", "i am so sleepy", "i feel sleepy",
              "need to rest", "i am worn out", "too tired to think", "i have no energy",
              "i've been working nonstop", "i slept badly", "i didnt sleep well",
              "i hardly slept last night", "no sleep last night", "my body aches from work",
              "i am physically exhausted", "i feel exhausted"],
    "thanks": ["thanks", "thank you", "you are the best", "appreciate it", "thanks bob",
               "thank you so much", "cheers", "that helped", "nice one", "thanks so much",
               "many thanks", "thank you very much", "you are awesome", "good job",
               "well done bob", "i appreciate you", "cool thanks", "thank you bob", "nice work",
               "great job", "you are great", "awesome job bob", "love it", "you are amazing",
               "youre the man"],
    "bye": ["bye", "good night", "see you later", "goodbye", "i am going to bed",
            "talk to you later", "gotta go", "time for bed", "see you tomorrow", "night bob",
            "good bye", "bye for now", "i am going to sleep", "talk later", "see you around",
            "i am leaving now", "farewell", "good night bob", "sleep time",
            "im going to sleep now", "off to bed", "heading to sleep", "time to sleep",
            "gotta go bye"],
    "joke": ["tell me a joke", "make me laugh", "say something funny", "got any jokes",
             "another joke", "i want a joke", "something funny please", "make a joke",
             "tell me a funny joke", "do you know any jokes", "say a joke", "make me laugh bob",
             "i need a laugh", "got a funny one"],
    "help": ["what can you do", "help me", "what do you know", "how do you work", "help",
             "what are your features", "what can i ask you", "what are your abilities",
             "what do you do", "how can you help me", "what can you help with",
             "list your features", "how does this work", "show me your commands",
             "instructions please", "what are you capable of", "how do i use this",
             "how do i use bob", "commands", "menu", "options", "what are your options",
             "what are you best at", "what is your specialty", "what are your strengths"],
    "learn": ["how do you learn", "are you trained", "what is your data", "are you an ai",
              "are you a robot", "how were you trained", "are you smart", "what are you",
              "are you a machine", "how do you think", "are you artificial", "how were you made",
              "how smart are you", "do you use machine learning", "are you a real person",
              "how do you work internally", "how do you actually work", "what is inside you",
              "what are you built with", "can you understand me", "do you understand what i say",
              "how do you understand me"],
    "mood_good": ["i am happy", "great day", "i feel good", "things are going well",
                  "i'm doing great", "feeling awesome", "best day ever", "i got good news",
                  "i am feeling great", "everything is fine", "i feel happy today",
                  "so happy right now", "i am in a great mood", "things are going great",
                  "i am excited", "what a great day", "i did it", "i won", "i passed my test",
                  "i got a promotion", "i finished my work", "i got the job", "life is great",
                  "i am in good spirits", "today was great", "my day went well", "feeling good",
                  "all good here", "feeling amazing", "feeling wonderful", "i feel fantastic",
                  "i am really proud", "i feel proud"],
    "mood_bad": ["i am sad", "bad day", "i feel down", "i am stressed", "i'm upset",
                 "i feel terrible", "rough day", "i'm anxious", "i feel bad",
                 "i am worried about it", "i feel sad", "i am so stressed", "i am really upset",
                 "i feel low", "i am overwhelmed", "i am nervous", "i feel awful today",
                 "i am angry", "i am feeling low", "feeling down", "feeling sad", "feeling blue",
                 "i feel really bad today", "i am frustrated", "so annoying today",
                 "i am so annoyed", "this is frustrating", "today is terrible", "terrible day",
                 "worst day ever"],
    "recall": ["what did i just say", "what did i tell you", "do you remember",
               "repeat what i said", "what did i say before", "repeat my last message",
               "what was my last message", "what was the last message i sent",
               "what did i type before", "tell me what i said earlier"],
    "my_name": ["what is my name", "do you know my name", "who am i", "say my name",
                "what's my name", "do you remember my name", "tell me my name",
                "who do you think i am", "do you remember who i am"],
    "lookup": ["who is albert einstein", "what is photosynthesis", "tell me about the moon",
               "who was napoleon", "what are black holes", "look up volcanoes",
               "search for pizza history", "define gravity", "what is the eiffel tower",
               "who discovered electricity", "what is the capital of france",
               "tell me about dinosaurs", "what is machine learning", "who invented the telephone",
               "look up the pyramids", "who was cleopatra", "what is the speed of light",
               "who's marie curie", "what's a black hole", "who's isaac newton", "what is rna",
               "what is an atom", "what is the internet", "what is a volcano", "what is inflation",
               "who painted the mona lisa", "who wrote hamlet", "explain gravity",
               "explain how rainbows form", "what is the largest planet",
               "when was the pyramid built", "where is mount everest", "tell me about the ocean",
               "what causes rain", "why is the sky blue", "how do airplanes fly",
               "when did the titanic sink", "what causes the seasons"],
    "math": ["what is 15% of 240", "calculate 12 * 7", "what is 5 plus 3",
             "how much is 20 divided by 4", "compute 9 times 8", "solve 100 minus 37",
             "what is 2 to the power of 10", "can you do math", "help me with a calculation",
             "what is 144 / 12", "add 8 and 12", "calculate 30 + 70", "what is 25% of 200",
             "multiply 6 by 7", "divide 100 by 4", "subtract 5 from 20", "what is 12 squared",
             "square root of 81"],
    "friend": ["are we friends", "are you my friend", "do you like me", "i like you bob",
               "you are my friend", "can we be friends", "are you my pal",
               "i think of you as a friend", "will you be my friend", "you are my buddy",
               "do you like talking to me"],
    "bored": ["i am bored", "nothing to do", "entertain me", "i'm bored", "so boring",
              "what should i do", "i am so bored", "nothing interesting to do", "i have free time",
              "i need something to do", "im bored bob"],
    "creator": ["who made you", "who created you", "who built you", "who is your creator",
                "who programmed you", "who developed you", "who is your developer",
                "who wrote you", "who programmed bob", "who is behind you",
                "who is the creator of this program", "who is bobs creator",
                "who created this bot"],
    "motivation": ["i need motivation", "cheer me up", "encourage me", "i need a pep talk",
                   "motivate me", "say something inspiring", "give me motivation",
                   "i need inspiration", "say something motivating", "encourage me please",
                   "i need a boost", "pump me up"],
    "read": ["can you read websites", "read this article", "summarize this page",
             "can you summarize", "read a file for me", "what can you read",
             "summarize an article", "can you read links", "can you summarize a website",
             "summarize a link", "can you read pdfs", "can you read articles", "read this link",
             "summarize my file", "can you read pdf files", "read a pdf for me", "summarize a pdf",
             "open a pdf document"],
    "weather": ["what is the weather", "weather in paris", "what's the weather like",
                "is it raining", "how hot is it", "how cold is it outside",
                "will it rain tomorrow", "weather forecast for london", "what is the temperature",
                "do i need an umbrella", "will it rain today", "is it going to snow",
                "do i need a coat", "is it hot outside", "how is the weather", "weather report",
                "weather today in cairo", "should i bring an umbrella", "what is the forecast"],
    "currency": ["what is the exchange rate", "convert 100 usd to eur",
                 "how much is 50 dollars in euros", "dollar to euro", "euro to pound rate",
                 "currency converter", "usd to gbp", "how much is 20 pounds in dollars",
                 "how many dollars is 50 euros", "how many yen is 20 dollars",
                 "convert dollars to euros", "what is the dollar rate", "pound to dollar",
                 "exchange rate for euros", "how much is 10 gbp in usd"],
    "news": ["what is the news", "latest headlines", "any news today", "top stories",
             "tell me the news", "what is happening in the world", "show me the headlines",
             "technology news", "sports news", "what's in the news", "what is happening today",
             "what's the news today", "any news", "what are today's headlines",
             "give me headlines", "world news", "what is going on today", "news please"],
    "ack": ["ok", "okay", "alright", "cool", "got it", "sure", "fine", "nice", "k"],
    "websearch": ["can you search the internet", "can you search the web", "search online for me",
                  "look something up online", "can you google", "can you browse the internet",
                  "are you connected to the internet", "can you search websites"],
    "qr": ["can you make qr codes", "can you read qr codes", "can you generate a qr code",
           "do you do qr codes", "qr code help", "i want a qr code", "can you scan qr codes",
           "make me a qr code", "how do i make a qr code", "qr codes"],
}

# Several replies per category, so feedback has something to choose between.
replies = {
    "greeting": ["Hey! Bob here.", "Hello, friend!", "Hi! Good to see you.", "Hey hey! What's on your mind?"],
    "feeling": ["I'm a few numbers in a trench coat, but I'm doing great.", "Doing fine. Trained and ready.",
                "Can't complain. My loss is low today."],
    "name": ["I'm Bob, a mini trained AI.", "Bob. Nice to meet you!"],
    "tired": ["Rest up. Even models need downtime between training runs.", "Tough day? Go easy on yourself.",
              "You earned some sleep. I'll be here tomorrow."],
    "thanks": ["Anytime!", "Happy to help.", "You're welcome, friend."],
    "bye": ["Good night!", "See you soon!", "Take care. I'll be here."],
    "joke": ["Why did the model fail the test? It memorized the answers and froze on new questions.",
             "I'd tell a joke about overfitting, but you've heard it before.",
             "My training data says this joke is funny. My training data is tiny."],
    "help": ["I can chat, remember you, look facts up, do math, check the weather, convert currencies, "
             "read news headlines, read pages, files, and PDFs, search the web, make and read QR codes, and "
             "learn new phrases from you. "
             "My data is tiny, so be gentle.",
             "Try: 'who is Ada Lovelace', 'what is 15% of 240', 'weather in paris', '100 usd to eur', "
             "or 'headlines'."],
    "learn": ["Yes! I was trained on example phrases. Data in, patterns out. Teach me more and I get smarter.",
              "I'm a small classifier: I turn your words into numbers and match them to categories I've learned."],
    "mood_good": ["Love that. Keep it going!", "That's great to hear!"],
    "mood_bad": ["Sorry to hear that. I'm here, and tomorrow's a new training run.",
                 "That sounds rough. Want to tell me what happened?",
                 "I'm sorry. If it feels heavy, talk to a friend or someone you trust. "
                 "They can help more than a tiny bot like me."],
    "read": ["Yes! Send a link like 'read https://example.com' or a file like 'read file notes.txt' "
             "(PDFs work too: 'read file report.pdf'). Then try 'summary', 'find <topic>', or 'save notes'."],
    "ack": ["Okay!", "Got it.", "Sounds good."],
    "qr": ["Yes, both! Make one: 'qr https://example.com' or 'qr wifi \"My Network\" password'. "
           "Read one: take a photo or screenshot, then say 'scan qr' for your newest image, "
           "or 'scan qr ~/storage/downloads/photo.jpg'."],
    "websearch": ["Yes! Start with 'web' and your question, like 'web how tall is mount everest'. "
                  "Your question goes to a search service (Tavily), then I read the top pages and show "
                  "the best sentences with their sources."],
    "math": ["Give me clear numbers, like 'what is 15% of 240' or '12 * 7'."],
    "friend": ["Of course we're friends. You built me.", "Friends for sure. I'm your project buddy."],
    "bored": ["Try teaching me a new phrase, or ask me to look something up, like 'who is Ada Lovelace'.",
              "Ask me a fact, a math problem, or a joke."],
    "creator": ["You built me, with a little help from Claude. Not a bad team.",
                "I was built in a chat, step by step, and you ran me yourself."],
    "motivation": ["You built a working AI from scratch. That's not nothing. Keep going.",
                   "One small step at a time. You've already done more than most people ever start.",
                   "Rest if you need it, then come back. Progress adds up."],
}

# =====================================================================
# Files Bob saves between runs (delete a file to make Bob forget that part)
# =====================================================================
LEARNED_FILE = "bob_learned.json"    # phrases you taught him
FEEDBACK_FILE = "bob_feedback.json"  # which replies you liked or disliked
MEMORY_FILE = "bob_memory.json"      # your name and recent messages

def load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            pass
    return default

def save_json(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f)

learned = load_json(LEARNED_FILE, {})
for intent, examples in learned.items():
    data.setdefault(intent, []).extend(examples)
feedback = load_json(FEEDBACK_FILE, {})
memory = load_json(MEMORY_FILE, {})
user_name = memory.get("name")
home_city = memory.get("city")
history = memory.get("history", [])

def save_memory():
    save_json(MEMORY_FILE, {"name": user_name, "city": home_city, "history": history[-100:]})

# =====================================================================
# 2. MODEL + 3. COMPUTE: words -> numbers -> a classifier (a plain CPU is plenty)
# =====================================================================
def clean(text):
    return text.replace("'", "")  # "what's" and "whats" now look the same

VOCAB = set()  # every word Bob has seen in his training data (used to fix typos)

def train():
    global VOCAB
    texts, labels = [], []
    for intent, examples in data.items():
        for e in examples:
            texts.append(clean(e))
            labels.append(intent)
    VOCAB = {w for t in texts for w in t.split()}
    VOCAB |= {w for word, _ in WORD_OPS for w in word.split()}   # plus, minus, times, ...
    VOCAB |= {w for w in FILLER if w.isalpha()}                  # calculate, compute, ...
    vec = TfidfVectorizer(ngram_range=(1, 2))
    X = vec.fit_transform(texts)
    model = LogisticRegression(max_iter=1000, C=10)
    model.fit(X, labels)  # TRAINING happens here
    return vec, model

vec, model = train()

# =====================================================================
# SPELLING: fix typos using words Bob already knows (standard library only)
# =====================================================================
def fix_spelling(msg):
    """'wat is photosynthesys' -> 'what is photosynthesis' when the words are close to known ones."""
    def repl(m):
        word = m.group(0)
        if word in SLANG:
            return SLANG[word]
        if len(word) < 3 or word in VOCAB or word.upper() in CURRENCY_CODES:
            return word
        for cand in difflib.get_close_matches(word, VOCAB, n=3, cutoff=0.75):
            if len(cand) >= len(word) or len(word) >= 5:  # short words may grow, not shrink
                return cand
        return word
    return re.sub(r"[a-z]+", repl, msg)

def classify(msg, fixed):
    """Try the message as typed and the spell-fixed version; keep whichever Bob is surer about."""
    best = None
    for text in (msg, fixed):
        probs = model.predict_proba(vec.transform([clean(text)]))[0]
        i = probs.argmax()
        if best is None or probs[i] > best[1]:
            best = (model.classes_[i], probs[i], text)
    return best  # (intent, confidence, text Bob went with)

def deslang(text):
    return re.sub(r"[a-z]+", lambda m: SLANG.get(m.group(0), m.group(0)), text)

def refine(intent, conf, text):
    """Sanity-check the classifier's guess. Returns (intent, confident)."""
    text = deslang(text)
    confident = conf >= CONFIDENCE
    if re.search(r"\byour name\b|\bcall you\b|\bwho are you\b|\bwho am i (?:talking|speaking) (?:to|with)\b", text):
        return "name", True
    words = set(re.findall(r"[a-z']+", text))
    is_question = looks_like_question(text) or text.startswith(tuple(PREFIXES))
    if intent == "qr" and text.startswith(("what is", "what's", "whats", "explain", "define", "tell me about")):
        return "lookup", True  # "what is a qr code" is a fact question, not a request to make one
    if intent in ("creator", "name") and text.startswith(("who is", "who was", "who's", "whos", "what is")) \
            and not (words & SECOND_PERSON):
        return "lookup", True  # "who is elon musk" isn't a question about Bob
    if intent == "math" and not re.search(r"\d|math|calculat|solve|compute|plus|minus|times|divid|add ", text):
        intent = "lookup"  # "what is dna" has no numbers, so it's a fact question
    if intent == "lookup" and not is_question:
        meaningful = [w for w in re.findall(r"[a-z]+", text) if w not in STOPWORDS]
        known = [w for w in meaningful if w in VOCAB]
        if not meaningful or conf < 0.40 or len(known) / len(meaningful) < 0.34:
            confident = False  # a weak guess on a non-question ("the quick brown fox") is just unsure
    return intent, confident

# =====================================================================
# TOOL 1: calculator (safe: it never uses eval)
# =====================================================================
OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
       ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
       ast.USub: operator.neg, ast.UAdd: operator.pos}

def safe_eval(node):
    if isinstance(node, ast.Expression):
        return safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in OPS:
        left, right = safe_eval(node.left), safe_eval(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > 100:
            raise ValueError("exponent too big")
        return OPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in OPS:
        return OPS[type(node.op)](safe_eval(node.operand))
    raise ValueError("not plain math")

def calculate(msg):
    """Return a number if msg is clean math, 'undefined' for divide-by-zero, else None."""
    text = msg.replace(",", "").replace("?", " ")
    text = re.sub(r"(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)", r"(\1/100)*\2", text)
    N = r"(\d+(?:\.\d+)?)"
    text = re.sub(rf"\badd\s+{N}\s+(?:and|to)\s+{N}", r"\1 + \2", text)
    text = re.sub(rf"\bsubtract\s+{N}\s+from\s+{N}", r"\2 - \1", text)
    text = re.sub(rf"\bmultiply\s+{N}\s+(?:by|and|with)\s+{N}", r"\1 * \2", text)
    text = re.sub(rf"\bdivide\s+{N}\s+by\s+{N}", r"\1 / \2", text)
    text = re.sub(rf"\bsquare root of\s+{N}", r"\1 ** 0.5", text)
    text = re.sub(rf"{N}\s+squared\b", r"\1 ** 2", text)
    text = re.sub(rf"{N}\s+cubed\b", r"\1 ** 3", text)
    for word, sym in WORD_OPS:
        text = re.sub(rf"\b{word}\b", f" {sym} ", text)
    text = re.sub(r"(?<=\d)\s*x\s*(?=\d)", " * ", text)
    text = text.replace("^", "**")

    leftover = re.sub(r"[0-9.+\-*/%()\s]", " ", text).split()
    if any(w not in FILLER for w in leftover):
        return None  # real words we don't recognize, so this isn't a math question
    expr = re.sub(r"[^0-9.+\-*/%()\s]", " ", text).strip()
    if len(re.findall(r"\d+(?:\.\d+)?", expr)) < 2:
        return None  # need at least two numbers

    try:
        value = safe_eval(ast.parse(expr, mode="eval"))
    except ZeroDivisionError:
        return "undefined"
    except Exception:
        return None
    if isinstance(value, float):
        value = int(value) if value.is_integer() else round(value, 6)
    return value

# =====================================================================
# TOOL 2: Wikipedia lookup (standard library only)
# =====================================================================
HEADERS = {"User-Agent": "BobChatbot/1.0 (learning project)"}

def get_json(url):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=8) as r:
        return json.load(r)

PREFIXES = ["who is", "who was", "what is", "what are", "what's", "whats", "who's", "whos",
            "tell me about", "look up", "search for", "define", "explain"]

def extract_topic(msg):
    """'wat is photosynthesys' -> 'photosynthesys'. Typos in the question words are tolerated,
    but the topic keeps your spelling so Wikipedia can correct it."""
    fixed = fix_spelling(msg)
    for text in (msg, fixed):  # check the question words as typed, then spell-fixed
        for prefix in PREFIXES:
            if text.startswith(prefix):
                n = len(prefix.split())
                return " ".join(msg.split()[n:]).strip(" ?.!") or msg
    return msg.strip(" ?.!") or msg

def looks_like_question(msg):
    words = msg.split()
    return msg.endswith("?") or (bool(words) and words[0] in {"who", "what", "when", "where", "why", "how"})

def search_wikipedia(term):
    q = urllib.parse.quote(term)
    return get_json("https://en.wikipedia.org/w/api.php?action=query&list=search"
                    f"&srsearch={q}&srlimit=1&srenablerewrites=1"
                    "&srinfo=suggestion%7Crewrittenquery&format=json")["query"]

def wikipedia_lookup(topic):
    """Return (title, short summary, corrected_topic or None), or None if offline / nothing found.
    Wikipedia's own search spots misspellings, so Bob uses its correction."""
    try:
        result = search_wikipedia(topic)
        info = result.get("searchinfo", {})
        hits = result.get("search", [])
        corrected = None
        if info.get("rewrittenquery"):              # Wikipedia already searched the fixed spelling
            corrected = info["rewrittenquery"]
        elif info.get("suggestion"):                # "did you mean ...": search that instead
            retry = search_wikipedia(info["suggestion"]).get("search", [])
            if retry:
                hits, corrected = retry, info["suggestion"]
        if not hits:
            return None
        title = hits[0]["title"]
        page = urllib.parse.quote(title.replace(" ", "_"))
        extract = get_json(f"https://en.wikipedia.org/api/rest_v1/page/summary/{page}").get("extract", "")
        short = ". ".join(extract.split(". ")[:2])  # first two sentences only
        return (title, short, corrected) if short else None
    except Exception:
        return None

def lookup_with_spellcheck(topic):
    """Ask Wikipedia first; if that fails, retry with Bob's own spell-fix of the topic."""
    result = wikipedia_lookup(topic)
    if result is None:
        fixed = fix_spelling(topic)
        if fixed != topic:
            result = wikipedia_lookup(fixed)
            if result:
                title, summary, _ = result
                return title, summary, fixed
    return result

# =====================================================================
# TOOL 3: live data from free sources (no API keys, standard library only)
#   weather -> Open-Meteo     currency -> Frankfurter (ECB rates)     news -> RSS headlines
# =====================================================================
LIVE_INTENTS = ("weather", "currency", "news")

# ---------- weather ----------
WEATHER_CODES = {0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
                 45: "fog", 48: "freezing fog", 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle",
                 56: "freezing drizzle", 57: "freezing drizzle", 61: "light rain", 63: "rain",
                 65: "heavy rain", 66: "freezing rain", 67: "freezing rain", 71: "light snow",
                 73: "snow", 75: "heavy snow", 77: "snow grains", 80: "light showers", 81: "showers",
                 82: "violent showers", 85: "light snow showers", 86: "snow showers",
                 95: "thunderstorm", 96: "thunderstorm with hail", 99: "thunderstorm with hail"}

CITY_STOPWORDS = {"what", "is", "the", "weather", "forecast", "temperature", "like", "how", "hot", "cold",
                  "outside", "today", "tomorrow", "tonight", "now", "right", "please", "bob", "tell", "me",
                  "show", "check", "it", "going", "to", "will", "rain", "raining", "snow", "snowing",
                  "whats", "what's", "do", "i", "need", "an", "umbrella", "a", "in", "for", "at", "near",
                  "of", "there", "get", "give", "current", "currently", "be", "are", "you"}

def extract_city(text):
    """'weather in new york today' -> 'new york'. Returns '' if no city was mentioned."""
    m = re.search(r"\b(?:in|for|at|near)\s+([^\W\d_][\w .'-]*?)(?:\s+(?:today|tomorrow|tonight|now|please))*\s*[?.!]*$", text)
    city = m.group(1).strip() if m else " ".join(w for w in re.findall(r"[\w']+", text) if w not in CITY_STOPWORDS)
    return "" if city in ("today", "tomorrow", "tonight", "now") else city

def temp(c):
    return f"{c:.0f}\u00b0C ({c * 9 / 5 + 32:.0f}\u00b0F)"

def get_weather(city, tomorrow=False):
    """Return lines to print, or None if offline or the place wasn't found."""
    try:
        q = urllib.parse.quote(city)
        geo = get_json(f"https://geocoding-api.open-meteo.com/v1/search?name={q}&count=1&language=en&format=json")
        places = geo.get("results") or []
        if not places:
            return None
        p = places[0]
        place = ", ".join(x for x in (p.get("name"), p.get("country")) if x)
        w = get_json("https://api.open-meteo.com/v1/forecast"
                     f"?latitude={p['latitude']}&longitude={p['longitude']}"
                     "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m"
                     "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
                     "&timezone=auto&forecast_days=2")
        d, day = w["daily"], (1 if tomorrow else 0)
        rain = (d.get("precipitation_probability_max") or [None, None])[day]
        daily = (f"{'Tomorrow' if tomorrow else 'Today'}: {WEATHER_CODES.get(d['weather_code'][day], 'mixed weather')}, "
                 f"high {temp(d['temperature_2m_max'][day])}, low {temp(d['temperature_2m_min'][day])}"
                 + (f", rain chance {rain}%" if rain is not None else "") + ".")
        if tomorrow:
            return [f"{place}. {daily}"]
        c = w["current"]
        now = (f"{place} now: {temp(c['temperature_2m'])}, {WEATHER_CODES.get(c['weather_code'], 'mixed weather')}, "
               f"feels {c['apparent_temperature']:.0f}\u00b0C, wind {c['wind_speed_10m']:.0f} km/h, "
               f"humidity {c['relative_humidity_2m']}%.")
        return [now, daily]
    except Exception:
        return None

def handle_weather(text):
    global home_city
    city, asked = extract_city(text), False
    if not city:
        if home_city:
            city = home_city
            print(f"Bob: Using your saved city, {home_city.title()}. (Say 'my city is ...' to change it.)")
        else:
            print("Bob: Which city?")
            city, asked = extract_city(input("You: ").strip().lower()), True
            if not city:
                print("Bob: No city, no weather.")
                return
    lines = get_weather(city, tomorrow="tomorrow" in text)
    if lines is None:
        print(f"Bob: I couldn't get the weather for '{city}'. Either I'm offline or I couldn't find that place.")
        return
    for line in lines:
        print("Bob:", line)
    print("     (Source: Open-Meteo, live forecast data)")
    if asked:
        home_city = city
        save_memory()
        print(f"Bob: I'll remember {city.title()} as your city.")

# ---------- currency ----------
CURRENCY_NAMES = {
    "us dollar": "USD", "us dollars": "USD", "canadian dollar": "CAD", "canadian dollars": "CAD",
    "australian dollar": "AUD", "australian dollars": "AUD", "new zealand dollar": "NZD",
    "new zealand dollars": "NZD", "singapore dollar": "SGD", "singapore dollars": "SGD",
    "hong kong dollar": "HKD", "hong kong dollars": "HKD", "swiss franc": "CHF", "swiss francs": "CHF",
    "korean won": "KRW", "brazilian real": "BRL", "brazilian reais": "BRL", "mexican peso": "MXN",
    "mexican pesos": "MXN", "dollar": "USD", "dollars": "USD", "bucks": "USD", "euro": "EUR",
    "euros": "EUR", "pound": "GBP", "pounds": "GBP", "sterling": "GBP", "yen": "JPY", "yuan": "CNY",
    "renminbi": "CNY", "rupee": "INR", "rupees": "INR", "franc": "CHF", "francs": "CHF",
    "krona": "SEK", "kronor": "SEK", "zloty": "PLN", "koruna": "CZK", "forint": "HUF",
    "rand": "ZAR", "baht": "THB", "ringgit": "MYR", "shekel": "ILS", "shekels": "ILS",
    "lira": "TRY", "rupiah": "IDR",
}
CURRENCY_CODES = {"USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY", "INR", "MXN", "BRL", "KRW",
                  "SEK", "NOK", "DKK", "PLN", "CZK", "HUF", "RON", "BGN", "NZD", "SGD", "HKD", "ZAR",
                  "THB", "PHP", "IDR", "MYR", "ILS", "ISK", "TRY"}
CURRENCY_HINTS = {"to", "in", "into", "convert", "exchange", "rate", "worth", "equals", "versus", "vs"}

def parse_currency(text):
    """'convert 100 usd to eur' or '50 dollars in euros' -> (100.0, 'USD', 'EUR'), else None."""
    t = text.lower().replace(",", "")
    for name in sorted(CURRENCY_NAMES, key=len, reverse=True):  # longest names first
        t = re.sub(rf"\b{name}\b", f" {CURRENCY_NAMES[name].lower()} ", t)
    m = re.search(r"how (?:many|much)\s+([a-z]{3})\s+(?:is|are|in|for)\s+(?:an?\s+)?(\d+(?:\.\d+)?)?\s*([a-z]{3})\b", t)
    if m and m.group(1).upper() in CURRENCY_CODES and m.group(3).upper() in CURRENCY_CODES:
        return (float(m.group(2)) if m.group(2) else 1.0), m.group(3).upper(), m.group(1).upper()
    words = re.findall(r"[a-z]+", t)
    codes = [w.upper() for w in words if w.upper() in CURRENCY_CODES]
    if len(codes) < 2 or not CURRENCY_HINTS.intersection(words):
        return None
    number = re.search(r"\d+(?:\.\d+)?", t)
    return (float(number.group()) if number else 1.0), codes[0], codes[1]

def get_rate(src, dst):
    """Return (rate, date) from Frankfurter, or None if offline or unsupported."""
    if src == dst:
        return 1.0, None
    try:
        data = get_json(f"https://api.frankfurter.dev/v1/latest?base={src}&symbols={dst}")
        return data["rates"][dst], data.get("date")
    except Exception:
        return None

def handle_currency(text):
    parsed = parse_currency(text)
    if not parsed:
        print("Bob: I can convert currencies. Try 'convert 100 usd to eur' or '50 dollars in euros'.")
        return
    amount, src, dst = parsed
    result = get_rate(src, dst)
    if result is None:
        print(f"Bob: I couldn't get the {src} to {dst} rate. Either I'm offline or my source doesn't cover one of them.")
        return
    rate, date = result
    shown = f"{int(amount):,}" if amount == int(amount) else f"{amount:,.2f}"
    print(f"Bob: {shown} {src} = {amount * rate:,.2f} {dst}")
    print(f"     (Rate {rate:g}{', ECB reference rate for ' + date if date else ''}. "
          "Updated once a day, not real-time. Source: Frankfurter)")

# ---------- news headlines ----------
BBC = "https://feeds.bbci.co.uk"
NEWS_FEEDS = {
    "top": [("BBC News", f"{BBC}/news/rss.xml"), ("The Guardian", "https://www.theguardian.com/world/rss"),
            ("NPR", "https://feeds.npr.org/1001/rss.xml")],
    "world": [("BBC News", f"{BBC}/news/world/rss.xml"), ("The Guardian", "https://www.theguardian.com/world/rss")],
    "technology": [("BBC News", f"{BBC}/news/technology/rss.xml")],
    "business": [("BBC News", f"{BBC}/news/business/rss.xml")],
    "health": [("BBC News", f"{BBC}/news/health/rss.xml")],
    "politics": [("BBC News", f"{BBC}/news/politics/rss.xml")],
    "sport": [("BBC Sport", f"{BBC}/sport/rss.xml")],
}
NEWS_TOPICS = {"technology": {"tech", "technology", "ai", "gadgets"}, "business": {"business", "economy", "markets"},
               "health": {"health", "medical"}, "politics": {"politics", "political"},
               "sport": {"sport", "sports", "football", "soccer"}, "world": {"world", "international"}}

def fetch_headlines(url, limit=5):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=8) as r:
        root = ET.fromstring(r.read(2_000_000))  # cap the download size
    titles = [(item.findtext("title") or "").strip() for item in root.iter("item")]
    return [t for t in titles if t][:limit]

def get_news(topic):
    """Try each feed for the topic in order; return (source, headlines) or None."""
    for source, url in NEWS_FEEDS[topic]:
        try:
            titles = fetch_headlines(url)
        except Exception:
            continue
        if titles:
            return source, titles
    return None

def handle_news(text):
    words = set(re.findall(r"[a-z]+", text))
    topic = next((t for t, keys in NEWS_TOPICS.items() if words & keys), "top")
    result = get_news(topic)
    if result is None:
        print("Bob: I couldn't load any headlines. Either I'm offline or the news feeds are down.")
        return
    source, titles = result
    print(f"Bob: Headlines from {source} ({'top stories' if topic == 'top' else topic}):")
    for i, title in enumerate(titles, 1):
        print(f"  {i}. {title}")
    print(f"     (Source: {source} RSS. I only read the headlines, not the articles, so I can't vouch for them.)")

# ---------- the decision: which free source fits? ----------
def pick_live_tool(intent, confident, text):
    """Trained category first; keyword rules as a backup. Returns 'weather', 'currency', 'news' or None."""
    if "temperature of" in text:
        return None  # "temperature of the sun" is a fact question, not a weather question
    if confident and intent in LIVE_INTENTS:
        return intent
    if parse_currency(text):
        return "currency"
    if re.search(r"\b(weather|forecast)\b", text) or ("temperature" in text and "temperature of" not in text):
        return "weather"
    if re.search(r"\b(headlines?|top stories|latest news|news today)\b", text):
        return "news"
    if confident and intent != "lookup":
        return None  # he's sure it's something else (like 'i got good news'), so trust that
    if re.search(r"\b(will it|going to|gonna) (rain|snow)\b|\b(umbrella|jacket|coat)\b", text):
        return "weather"
    if re.search(r"\b(what is|what's|whats) (happening|going on)\b|\b(any|the|world|business|sport|sports|health|tech|technology) news\b|\bnews please\b", text):
        return "news"
    return None

# =====================================================================
# READING: Bob reads a web page or text file, then writes short statements from it.
# He PICKS the most relevant sentences from the source. Writing new wording takes a bigger model.
# =====================================================================
NOTES_FILE = "bob_notes.txt"
doc = None  # the page or file Bob is currently reading

class PageText(HTMLParser):
    """Collects the page title and the text inside <p> tags, skipping menus, scripts, and footers."""
    SKIP = {"script", "style", "nav", "header", "footer", "aside", "form", "noscript", "svg"}

    def __init__(self):
        super().__init__()
        self.title, self.paragraphs = "", []
        self._skip, self._in_title, self._in_p, self._buf = 0, False, False, []

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self._skip += 1
        elif tag == "title":
            self._in_title = True
        elif tag == "p" and not self._skip:
            self._in_p, self._buf = True, []

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip:
            self._skip -= 1
        elif tag == "title":
            self._in_title = False
        elif tag == "p" and self._in_p:
            text = " ".join("".join(self._buf).split())
            if text:
                self.paragraphs.append(text)
            self._in_p = False

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif self._in_p and not self._skip:
            self._buf.append(data)

def split_sentences(paragraphs):
    seen, out = set(), []
    for para in paragraphs:
        for sentence in re.split(r'(?<=[.!?])\s+(?=[A-Z0-9"\'(])', para):
            sentence = sentence.strip()
            if 40 <= len(sentence) <= 400 and sentence not in seen:
                seen.add(sentence)
                out.append(sentence)
    return out[:400]

def fetch_url(url):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=10) as r:
        ctype = r.headers.get_content_type()
        if ctype == "application/pdf":
            return ctype, r.read(20_000_000)  # PDFs can be big; cap the download at 20 MB
        if ctype not in ("text/html", "application/xhtml+xml", "text/plain"):
            raise ValueError(f"I can't read '{ctype}' yet. I can read web pages, plain text, and PDFs.")
        charset = r.headers.get_content_charset() or "utf-8"
        text = r.read(2_000_000).decode(charset, errors="replace")  # cap the download size
    return ("text/plain" if ctype == "text/plain" else "text/html"), text

# ---------- PDF reading (needs the small 'pypdf' package: pip install pypdf) ----------
MAX_PDF_PAGES = 100
Loaded = namedtuple("Loaded", "title source sentences pages note")  # pages: page number per sentence, or None

def pdf_to_pages(source, max_pages=MAX_PDF_PAGES):
    """Return (metadata title, [(page number, text)], total page count) from a PDF path or bytes."""
    try:
        from pypdf import PdfReader
    except ImportError:
        raise ValueError("To read PDFs I need one small add-on. Run: pip install pypdf  (then restart me)")
    import logging
    logging.getLogger("pypdf").setLevel(logging.CRITICAL)  # keep the library's warnings off your screen
    try:
        reader = PdfReader(io.BytesIO(source) if isinstance(source, bytes) else source)
        if reader.is_encrypted and not reader.decrypt(""):
            raise ValueError("That PDF is password protected, so I can't read it.")
        total = len(reader.pages)
        title = ((reader.metadata.title if reader.metadata else "") or "").strip()
        pages = [(n + 1, reader.pages[n].extract_text() or "") for n in range(min(total, max_pages))]
    except ValueError:
        raise
    except Exception:
        raise ValueError("I couldn't open that PDF. It may be damaged, protected, or in an unusual format.")
    return title, pages, total

def clean_pdf_text(text):
    """Undo PDF line breaks: drop page numbers, re-join split words, turn line breaks into spaces."""
    lines = [l.strip() for l in text.splitlines()
             if not re.fullmatch(r"\s*(?:page\s+)?\d{1,4}(?:\s+of\s+\d{1,4})?\s*", l, re.I)]
    for i, line in enumerate(lines):  # a short line with no ending punctuation, standing alone, is a heading
        prev, nxt = (lines[i - 1] if i else ""), (lines[i + 1] if i + 1 < len(lines) else "")
        if (line and len(line.split()) <= 8 and not line.endswith((".", "!", "?", ":", ";", ","))
                and (not prev or prev.endswith((".", "!", "?", ":"))) and nxt[:1].isupper()):
            lines[i] = line + "."
    text = "\n".join(lines)
    text = re.sub(r"(?<=\w)-\n(?=[a-z])", "", text)
    return " ".join(re.sub(r"\s*\n\s*", " ", text).split())

def pdf_sentences(pages):
    seen, sentences, numbers = set(), [], []
    for number, text in pages:
        for sentence in split_sentences([clean_pdf_text(text)]):
            if sentence not in seen and len(sentences) < 1500:
                seen.add(sentence)
                sentences.append(sentence)
                numbers.append(number)
    return sentences, numbers

def load_document(target, max_pages=MAX_PDF_PAGES):
    """Read a web link or a local .txt/.md/.html/.pdf file. Returns a Loaded tuple."""
    pdf_source, text, ctype = None, "", "text/plain"
    if re.match(r"https?://", target):
        ctype, text = fetch_url(target)
        if ctype == "application/pdf":
            pdf_source = text  # raw bytes
    else:
        target = os.path.expanduser(target)  # so ~/storage/downloads/x.pdf works in Termux
        lower = target.lower()
        if not lower.endswith((".txt", ".md", ".html", ".htm", ".pdf")):
            raise ValueError("I can read web links and .txt, .md, .html, or .pdf files.")
        if not os.path.exists(target):
            raise ValueError(f"I can't find the file '{target}'. Check the name and the folder.")
        if lower.endswith(".pdf"):
            if os.path.getsize(target) > 50_000_000:
                raise ValueError("That PDF is over 50 MB, which is too big for me.")
            pdf_source = target
        else:
            with open(target, encoding="utf-8", errors="replace") as f:
                text = f.read(2_000_000)
            ctype = "text/html" if lower.endswith((".html", ".htm")) else "text/plain"

    if pdf_source is not None:
        meta_title, pages, total = pdf_to_pages(pdf_source, max_pages)
        if sum(len(t.strip()) for _, t in pages) < 200:
            raise ValueError("This PDF has almost no text. It's probably scanned images, "
                             "which I can't read without OCR.")
        sentences, numbers = pdf_sentences(pages)
        first_line = next((l.strip() for _, t in pages for l in t.splitlines() if l.strip()), target)
        title = meta_title if len(meta_title) > 3 else first_line
        note = f"{len(pages)} of {total} pages" if total > len(pages) else f"{total} pages"
        return Loaded(title[:100], target, sentences, numbers, note)

    if ctype == "text/plain":
        paragraphs = [" ".join(p.split()) for p in re.split(r"\n\s*\n", text)]
        title = next((line.strip("# ").strip() for line in text.splitlines() if line.strip()), target)
    else:
        parser = PageText()
        parser.feed(text)
        paragraphs = parser.paragraphs
        if sum(len(p) for p in paragraphs) < 200:  # unusual markup: fall back to all visible text
            visible = re.sub(r"(?is)<(script|style).*?</\1>", " ", text)
            paragraphs = [" ".join(re.sub(r"<[^>]+>", " ", visible).split())]
        title = " ".join(parser.title.split()) or target
    return Loaded(title[:100], target, split_sentences(paragraphs), None, "")

def pick_summary(X, n=3):
    """Centroid method: choose the sentences closest to the page's overall word pattern."""
    count = X.shape[0]
    if count <= n:
        return list(range(count))
    scores = cosine_similarity(X, np.asarray(X.mean(axis=0))).ravel()
    scores[:3] += 0.05  # intros usually matter
    return sorted(int(i) for i in scores.argsort()[::-1][:n])

def handle_read(target):
    global doc
    try:
        loaded = load_document(target)
    except ValueError as e:
        print("Bob:", e)
        return
    except Exception:
        print("Bob: I couldn't open that. Either I'm offline, the site blocked me, or the path is wrong.")
        return
    title, source, sentences = loaded.title, loaded.source, loaded.sentences
    if len(sentences) < 3:
        print("Bob: I found too little readable text. Pages that need JavaScript, a login, "
              "or are mostly images can't be read by me.")
        return
    try:
        page_vec = TfidfVectorizer(stop_words="english")
        X = page_vec.fit_transform(sentences)
    except ValueError:
        print("Bob: That text has too few real words for me to analyze.")
        return
    doc = {"title": title, "source": source, "sentences": sentences, "vec": page_vec, "X": X,
           "src": [source] * len(sentences), "pages": loaded.pages, "last": [], "last_src": [], "last_idx": []}
    size = f"{len(sentences)} sentences, {loaded.note}" if loaded.note else f"{len(sentences)} sentences"
    print(f"Bob: Read '{title}' ({size}). Say 'find <topic>' to search it, "
          "or 'save notes' to keep my summary.")
    handle_summary()

def page_tag(i):
    """' (p. 3)' for sentences from a PDF; nothing for other sources."""
    return f" (p. {doc['pages'][i]})" if i is not None and doc.get("pages") else ""

def handle_summary():
    if doc is None:
        print("Bob: Give me something to read first, like 'read https://...' or 'read file notes.txt'.")
        return
    idx = pick_summary(doc["X"])
    doc["last"], doc["last_src"], doc["last_idx"] = [doc["sentences"][i] for i in idx], [doc["src"][i] for i in idx], idx
    print(f"Bob: Summary of '{doc['title']}':")
    for sentence, i in zip(doc["last"], idx):
        print(f"  - {sentence}{page_tag(i)}")
    print(f"     (Source: {', '.join(dict.fromkeys(doc['last_src']))}. "
          "These are sentences I picked from it, not my own wording.)")

def handle_find(query):
    if doc is None:
        print("Bob: Give me something to read first, like 'read https://...'.")
        return
    sims = cosine_similarity(doc["vec"].transform([query]), doc["X"]).ravel()
    best = sorted(int(i) for i in sims.argsort()[::-1][:2] if sims[i] > 0.05)
    if not best:
        print(f"Bob: I couldn't find anything about '{query}' in this page.")
        return
    doc["last"], doc["last_src"], doc["last_idx"] = [doc["sentences"][i] for i in best], [doc["src"][i] for i in best], best
    print(f"Bob: What '{doc['title']}' says about '{query}':")
    for sentence, i in zip(doc["last"], best):
        print(f"  - {sentence}{page_tag(i)}")
    print(f"     (Source: {', '.join(dict.fromkeys(doc['last_src']))})")

def handle_save():
    if doc is None or not doc["last"]:
        print("Bob: I have nothing to save yet. Read something and ask for a 'summary' or 'find <topic>' first.")
        return
    with open(NOTES_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.date.today().isoformat()}] {doc['title']}\n"
                f"Source: {', '.join(dict.fromkeys(doc['last_src']))}\n")
        idx = doc.get("last_idx") or [None] * len(doc["last"])
        f.write("\n".join(f"- {sentence}{page_tag(i)}" for sentence, i in zip(doc["last"], idx)) + "\n\n")
    print(f"Bob: Saved to {NOTES_FILE}, with the source and today's date.")

# =====================================================================
# WEB SEARCH: search -> open the top pages -> pick the best sentences -> show sources.
# Works like a research assistant's first pass. He never rewrites or judges; he quotes and cites.
# Uses Tavily, Serper, Exa, or Brave (whichever keys you give him), and falls back to the next if one fails.
# With no keys at all he tries Tavily's limited keyless mode, then Wikipedia.
# =====================================================================
class SearchError(Exception):
    def __init__(self, message, problems=None):
        super().__init__(message)
        self.problems = problems or []

class ApiError(Exception):
    """One search service said no. code 0 means we couldn't reach it at all."""
    def __init__(self, code, detail=""):
        super().__init__(f"{code} {detail}")
        self.code, self.detail = code, detail

# Four search services. Bob uses every one you have a key for, in order, and moves on if one fails.
PROVIDERS = {
    "tavily": {"label": "Tavily", "env": "TAVILY_API_KEY", "signup": "app.tavily.com"},
    "serper": {"label": "Serper", "env": "SERPER_API_KEY", "signup": "serper.dev"},
    "exa": {"label": "Exa", "env": "EXA_API_KEY", "signup": "exa.ai"},
    "brave": {"label": "Brave", "env": "BRAVE_API_KEY", "signup": "api.search.brave.com"},
}

KEY_FILE = "bob_keys.json"       # your keys, kept in one small private file (apps like Pydroid have no terminal)
OLD_KEY_FILE = "tavily_key.txt"  # older versions of Bob saved a single Tavily key here

def clean_key(text):
    return text.strip().strip("'\"").strip()

def key_folders():
    """Where Bob looks for the key file: next to bob.py first, then the current folder."""
    folders = []
    try:
        folders.append(os.path.dirname(os.path.abspath(__file__)))
    except NameError:
        pass
    folders.append(os.getcwd())
    return list(dict.fromkeys(folders))

def load_key_file():
    """Return {service: key} from bob_keys.json (and the old tavily_key.txt)."""
    saved = {}
    for folder in key_folders():
        try:
            with open(os.path.join(folder, OLD_KEY_FILE), encoding="utf-8") as f:
                old = clean_key(f.readline())
            if old:
                saved.setdefault("tavily", old)
        except OSError:
            pass
        try:
            with open(os.path.join(folder, KEY_FILE), encoding="utf-8") as f:
                for name, value in json.load(f).items():
                    if isinstance(value, str) and clean_key(value):
                        saved.setdefault(name, clean_key(value))
        except (OSError, ValueError, AttributeError):
            pass
    return saved

def get_key(provider):
    """(key, where it came from) for one service. The key is '' if there isn't one."""
    key = clean_key(os.environ.get(PROVIDERS[provider]["env"], ""))
    if key:
        return key, f"the {PROVIDERS[provider]['env']} environment variable"
    key = load_key_file().get(provider, "")
    return (key, "your key file") if key else ("", "")

def write_key_file(name, value):
    path = os.path.join(key_folders()[0], KEY_FILE)
    try:
        try:
            with open(path, encoding="utf-8") as f:
                saved = json.load(f)
        except (OSError, ValueError):
            saved = {}
        saved[name] = value
        with open(path, "w", encoding="utf-8") as f:
            json.dump(saved, f)
    except OSError:
        return None
    return path

def save_search_key(provider, key):
    path = write_key_file(provider, clean_key(key))
    if path is None:
        print("Bob: I couldn't save the key file in that folder.")
        return
    print(f"Bob: Saved your {PROVIDERS[provider]['label']} key to {path}. "
          "Keep that file private. Type 'web status' to test it.")

def guess_provider(key):
    """A guess from the shape of the key. Wrong guesses are easy to fix by naming the service."""
    if key.startswith("tvly-"):
        return "tavily"
    if key.startswith("BSA"):
        return "brave"
    if re.fullmatch(r"[0-9a-f]{40}", key):
        return "serper"
    if re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", key):
        return "exa"
    return None

def mask_key(key):
    return f"{len(key)} characters, starts with '{key[:5]}'"

def error_detail(e):
    """Pull the service's own explanation out of an HTTP error, if it sent one."""
    try:
        payload = json.loads(e.read().decode("utf-8", "replace"))
        detail = payload.get("detail", payload.get("error", payload.get("message", payload)))
        return str(detail.get("error", detail) if isinstance(detail, dict) else detail)[:150]
    except Exception:
        return ""

def http_json(url, headers, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, headers={"User-Agent": HEADERS["User-Agent"], **headers},
                                 method="GET" if body is None else "POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        raise ApiError(e.code, error_detail(e))
    except Exception as e:  # no internet, blocked, certificate trouble, or timeout
        raise ApiError(0, f"{type(e).__name__}: {str(e)[:100]}")

def search_tavily(query, key, n):
    headers = {"Content-Type": "application/json"}
    headers.update({"Authorization": f"Bearer {key}"} if key else {"X-Tavily-Access-Mode": "keyless"})
    data = http_json("https://api.tavily.com/search", headers, {"query": query, "max_results": n})
    return [{"title": r.get("title"), "url": r.get("url"), "content": r.get("content", "")}
            for r in data.get("results", [])]

def search_serper(query, key, n):
    data = http_json("https://google.serper.dev/search",
                     {"X-API-KEY": key, "Content-Type": "application/json"}, {"q": query, "num": n})
    return [{"title": r.get("title"), "url": r.get("link"), "content": r.get("snippet", "")}
            for r in data.get("organic", [])]

def search_exa(query, key, n):
    data = http_json("https://api.exa.ai/search", {"x-api-key": key, "Content-Type": "application/json"},
                     {"query": query, "numResults": n, "contents": {"text": {"maxCharacters": 1200}}})
    return [{"title": r.get("title"), "url": r.get("url"), "content": r.get("text", "")}
            for r in data.get("results", [])]

def search_brave(query, key, n):
    url = "https://api.search.brave.com/res/v1/web/search?" + urllib.parse.urlencode({"q": query, "count": n})
    data = http_json(url, {"X-Subscription-Token": key, "Accept": "application/json"})
    return [{"title": r.get("title"), "url": r.get("url"), "content": re.sub(r"<[^>]+>", "", r.get("description", ""))}
            for r in (data.get("web") or {}).get("results", [])]

SEARCH_FUNCS = {"tavily": search_tavily, "serper": search_serper, "exa": search_exa, "brave": search_brave}

def explain(provider, e, has_key):
    """Turn an ApiError into one plain sentence."""
    label = PROVIDERS[provider]["label"]
    detail = f": {e.detail}" if e.detail else ""
    if e.code in (401, 403):
        return (f"{label} rejected the key (error {e.code}{detail})." if has_key
                else f"{label} refused keyless mode (error {e.code}{detail}).")
    if e.code in (400, 402, 429) or 430 <= e.code < 500:
        return f"{label} refused the request (error {e.code}{detail}). Usually the free credits or rate limit ran out."
    if e.code >= 500:
        return f"{label} is having server trouble (error {e.code})."
    return f"{label} could not be reached ({e.detail})."

def search_order():
    """Services with a key (your favorite first), then Tavily's keyless mode as a last resort."""
    order = [p for p in PROVIDERS if get_key(p)[0]]
    favorite = load_key_file().get("_prefer")
    if favorite in order:
        order.remove(favorite)
        order.insert(0, favorite)
    if "tavily" not in order:
        order.append("tavily")
    return order

def web_search(query, n=5):
    """Return (service name, results, skipped notes). Raises SearchError if every service fails."""
    problems = []
    for provider in search_order():
        key = get_key(provider)[0]
        label = PROVIDERS[provider]["label"] + (" (keyless)" if provider == "tavily" and not key else "")
        try:
            results = [r for r in SEARCH_FUNCS[provider](query, key, n)
                       if str(r.get("url", "")).startswith(("http://", "https://"))]
        except ApiError as e:
            problems.append(explain(provider, e, bool(key)))
            continue
        if results:
            return label, results, problems
        problems.append(f"{label} found no results.")
    raise SearchError("No search service could answer.", problems)

def web_status():
    """Check the internet and every service you have a key for, without printing any whole key."""
    print("Bob: Search check:")
    try:
        get_json("https://en.wikipedia.org/api/rest_v1/page/summary/Earth")
        print("  - Internet: working (I reached Wikipedia).")
    except Exception as e:
        print(f"  - Internet: I couldn't reach Wikipedia ({type(e).__name__}). If this fails, no search service "
              "can work. Check your connection, or the app's internet permission.")
    order = search_order()
    for provider, info in PROVIDERS.items():
        key, source = get_key(provider)
        if not key and provider != "tavily":
            print(f"  - {info['label']}: no key. Free key at {info['signup']}, then: web setkey {provider} <key>")
            continue
        where = f"key from {source} ({mask_key(key)})" if key else "no key, using keyless mode"
        try:
            SEARCH_FUNCS[provider]("test", key, 1)
            print(f"  - {info['label']}: working ({where}).")
        except ApiError as e:
            print(f"  - {info['label']}: FAILED ({where}). {explain(provider, e, bool(key))}")
    print(f"  - Order I try: {', '.join(PROVIDERS[p]['label'] for p in order)}. Change with: web use <name>")

def read_result(result):
    """Open one search result. Falls back to the search snippet if the page can't be read."""
    try:
        sentences = load_document(result["url"], max_pages=15).sentences
    except Exception:
        sentences = []
    if len(sentences) < 3:  # a thin or unreadable page: add the search service's own snippet
        sentences = sentences + split_sentences([result.get("content", "")])
    return result, sentences[:80]

def numbers_in(text):
    return set(re.findall(r"\d[\d,]*\.?\d*", text))

def handle_web(question):
    global doc
    print(f"Bob: Searching the web for: {question}  (your question goes to your search service)")
    try:
        service, results, skipped = web_search(question)
    except SearchError as e:
        for line in e.problems:
            print(f"  - {line}")
        print("Bob: Web search isn't working right now, so I'll try Wikipedia instead...")
        result = lookup_with_spellcheck(extract_topic(question.lower()))
        if result:
            title, summary, _ = result
            print(f"Bob: {summary} (Source: Wikipedia, '{title}')")
        else:
            print("Bob: Wikipedia had nothing either. Type 'web status' to see which service is failing.")
        return
    print(f"     (Answered by {service}." + (f" Skipped: {' '.join(skipped)}" if skipped else "") + ")")

    with ThreadPoolExecutor(max_workers=5) as pool:  # open the pages at the same time
        pages = list(pool.map(read_result, results[:5]))
    candidates = [(sentence, r["url"]) for r, sentences in pages for sentence in sentences]
    if not candidates:
        print("Bob: I found pages but couldn't read any text from them.")
        return

    texts = [c[0] for c in candidates]
    try:
        vec = TfidfVectorizer(stop_words="english")
        X = vec.fit_transform(texts + [question])
    except ValueError:
        print("Bob: I couldn't make sense of those results.")
        return
    sims = cosine_similarity(X[-1], X[:-1]).ravel()

    chosen, per_source = [], {}
    for i in sims.argsort()[::-1]:
        sentence, url = candidates[i]
        if sims[i] < 0.08 or len(chosen) == 3:
            break
        if per_source.get(url, 0) >= 2 or sentence in [c[0] for c in chosen]:
            continue  # spread across sources, no repeats
        per_source[url] = per_source.get(url, 0) + 1
        chosen.append((sentence, url))
    if not chosen:
        print("Bob: I opened the top results but found no sentence that clearly answers that.")
        return

    urls = list(dict.fromkeys(url for _, url in chosen))
    titles = {r["url"]: (r.get("title") or r["url"]) for r in results}
    print(f"Bob: Here's what the web says about '{question}':")
    for sentence, url in chosen:
        print(f"  - {sentence} [{urls.index(url) + 1}]")
    print("  Sources:")
    for n, url in enumerate(urls, 1):
        print(f"   [{n}] {titles[url][:60]} - {url}")
    per_url_numbers = [numbers_in(" ".join(sn for sn, u in chosen if u == url)) for url in urls]
    if len(urls) > 1 and all(per_url_numbers) and not set.intersection(*per_url_numbers):
        print("     Heads up: these sources give different numbers. Check them before you rely on one.")
    print("     (From the web, not verified. I picked these sentences; I can't judge which source is right.)")

    # Let the person say 'find <topic>' or 'save notes' on these results too
    doc = {"title": f"Web search: {question}", "source": ", ".join(urls), "sentences": texts,
           "vec": vec, "X": X[:-1], "src": [c[1] for c in candidates],
           "last": [c[0] for c in chosen], "last_src": [c[1] for c in chosen]}

# =====================================================================
# QR CODES
#   Making: pure Python, nothing to install (bytes mode, versions 1-10, up to ~210 characters)
#   Reading: needs ONE decoder: OpenCV, pyzbar, or the zbarimg tool (Bob tries them in that order)
# =====================================================================
QR_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
            7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}
# per version: (error-correction codewords per block, [(number of blocks, data codewords per block), ...])
QR_BLOCKS = {
    "M": {1: (10, [(1, 16)]), 2: (16, [(1, 28)]), 3: (26, [(1, 44)]), 4: (18, [(2, 32)]), 5: (24, [(2, 43)]),
          6: (16, [(4, 27)]), 7: (18, [(4, 31)]), 8: (22, [(2, 38), (2, 39)]), 9: (22, [(3, 36), (2, 37)]),
          10: (26, [(4, 43), (1, 44)])},
    "L": {1: (7, [(1, 19)]), 2: (10, [(1, 34)]), 3: (15, [(1, 55)]), 4: (20, [(1, 80)]), 5: (26, [(1, 108)]),
          6: (18, [(2, 68)]), 7: (20, [(2, 78)]), 8: (24, [(2, 97)]), 9: (30, [(2, 116)]),
          10: (18, [(2, 68), (2, 69)])},
}
QR_LEVEL_BITS = {"L": 1, "M": 0}

# Reed-Solomon math over GF(256), the error correction that lets a damaged code still scan
_EXP, _LOG = [0] * 512, [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i], _LOG[_x] = _x, _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]

def gf_mul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]

def rs_remainder(data, n):
    """The n error-correction codewords for a block of data codewords."""
    gen = [1]
    for i in range(n):
        nxt = [0] * (len(gen) + 1)
        for j, c in enumerate(gen):
            nxt[j] ^= c
            nxt[j + 1] ^= gf_mul(c, _EXP[i])
        gen = nxt
    rem = list(data) + [0] * n
    for i in range(len(data)):
        coef = rem[i]
        if coef:
            for j in range(1, len(gen)):
                rem[i + j] ^= gf_mul(gen[j], coef)
    return rem[len(data):]

def qr_codewords(payload, version, level):
    ec_len, groups = QR_BLOCKS[level][version]
    capacity = sum(count * size for count, size in groups)
    bits = "0100" + format(len(payload), "08b" if version < 10 else "016b")
    bits += "".join(format(b, "08b") for b in payload)
    bits += "0" * min(4, capacity * 8 - len(bits))
    bits += "0" * (-len(bits) % 8)
    data = [int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)]
    pad = 0
    while len(data) < capacity:
        data.append(0xEC if pad % 2 == 0 else 0x11)
        pad += 1
    blocks, pos = [], 0
    for count, size in groups:
        for _ in range(count):
            blocks.append(data[pos:pos + size])
            pos += size
    ecs = [rs_remainder(block, ec_len) for block in blocks]
    out = []
    for i in range(max(len(b) for b in blocks)):  # interleave the blocks
        out += [b[i] for b in blocks if i < len(b)]
    for i in range(ec_len):
        out += [e[i] for e in ecs]
    return out

def qr_draw_format(m, size, level, mask):
    data = QR_LEVEL_BITS[level] << 3 | mask
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    bits = (data << 10 | rem) ^ 0x5412
    bit = lambda i: (bits >> i) & 1 == 1
    def put(x, y, dark):
        m[y][x] = dark
    for i in range(0, 6):
        put(8, i, bit(i))
    put(8, 7, bit(6))
    put(8, 8, bit(7))
    put(7, 8, bit(8))
    for i in range(9, 15):
        put(14 - i, 8, bit(i))
    for i in range(0, 8):
        put(size - 1 - i, 8, bit(i))
    for i in range(8, 15):
        put(8, size - 15 + i, bit(i))
    put(8, size - 8, True)  # the one module that is always dark

def qr_penalty(m):
    n, score = len(m), 0
    for lines in (m, [list(col) for col in zip(*m)]):
        for line in lines:
            run, prev = 1, line[0]
            for v in line[1:]:
                if v == prev:
                    run += 1
                else:
                    score += 3 + run - 5 if run >= 5 else 0
                    run, prev = 1, v
            score += 3 + run - 5 if run >= 5 else 0
            text = "".join("1" if v else "0" for v in line)
            for pattern in ("10111010000", "00001011101"):
                k = text.find(pattern)
                while k >= 0:
                    score += 40
                    k = text.find(pattern, k + 1)
    for y in range(n - 1):
        for x in range(n - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(sum(row) for row in m)
    total = n * n
    score += ((abs(dark * 20 - total * 10) + total - 1) // total - 1) * 10
    return score

def qr_build(payload, version, level):
    size = 17 + 4 * version
    mod = [[False] * size for _ in range(size)]
    fn = [[False] * size for _ in range(size)]
    def setf(x, y, dark):
        mod[y][x] = dark
        fn[y][x] = True
    for i in range(size):                      # timing lines
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):  # the three big corner squares
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                if 0 <= cx + dx < size and 0 <= cy + dy < size:
                    setf(cx + dx, cy + dy, max(abs(dx), abs(dy)) not in (2, 4))
    pos = QR_ALIGN[version]                    # the small alignment squares
    for i, cx in enumerate(pos):
        for j, cy in enumerate(pos):
            if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)
    probe = [[None] * size for _ in range(size)]  # reserve the format areas (found by drawing once)
    qr_draw_format(probe, size, level, 0)
    for y in range(size):
        for x in range(size):
            if probe[y][x] is not None:
                fn[y][x] = True
    if version >= 7:                           # version information blocks
        rem = version
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        bits = version << 12 | rem
        for i in range(18):
            a, b = size - 11 + i % 3, i // 3
            setf(a, b, (bits >> i) & 1 == 1)
            setf(b, a, (bits >> i) & 1 == 1)

    data = qr_codewords(payload, version, level)
    i = 0
    for right in range(size - 1, 0, -2):       # zigzag the data in, two columns at a time
        if right <= 6:
            right -= 1
        for vert in range(size):
            for j in range(2):
                x = right - j
                y = size - 1 - vert if (right + 1) & 2 == 0 else vert
                if not fn[y][x] and i < len(data) * 8:
                    mod[y][x] = (data[i >> 3] >> (7 - (i & 7))) & 1 == 1
                    i += 1

    best = None
    for mask in range(8):                      # try all 8 patterns, keep the most scannable
        formulas = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
                    lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
                    lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
                    lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0]
        trial = [[mod[y][x] ^ (formulas[mask](x, y) and not fn[y][x]) for x in range(size)] for y in range(size)]
        qr_draw_format(trial, size, level, mask)
        score = qr_penalty(trial)
        if best is None or score < best[0]:
            best = (score, trial)
    return best[1]

def make_qr(text):
    """Return the QR code for text as a grid of True (dark) / False (light)."""
    payload = text.encode("utf-8")
    for level in ("M", "L"):
        for version in range(1, 11):
            capacity = sum(c * s for c, s in QR_BLOCKS[level][version][1])
            if 4 + (8 if version < 10 else 16) + 8 * len(payload) <= capacity * 8:
                return qr_build(payload, version, level)
    raise ValueError("That's too long for me. I can do about 270 characters at most, so try a shorter link or text.")

def qr_lines(m, border=2):
    """Draw the code with block characters, two rows of modules per line of text."""
    n = len(m)
    light = lambda x, y: not (0 <= x < n and 0 <= y < n and m[y][x])
    lines = []
    for y in range(-border, n + border, 2):
        lines.append("".join(
            "\u2588" if light(x, y) and light(x, y + 1) else "\u2580" if light(x, y)
            else "\u2584" if light(x, y + 1) else " " for x in range(-border, n + border)))
    return lines

def write_qr_png(m, path, scale=10, border=4):
    n = len(m)
    rows = []
    for y in range(-border, n + border):
        line = b"".join((b"\x00" if (0 <= x < n and 0 <= y < n and m[y][x]) else b"\xff") * scale
                        for x in range(-border, n + border))
        rows += [b"\x00" + line] * scale
    size = (n + 2 * border) * scale
    def chunk(tag, body):
        return struct.pack(">I", len(body)) + tag + body + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 0, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(png)

def qr_save_dir():
    for folder in ("~/storage/downloads", "/storage/emulated/0/Download", "~/storage/shared/Download"):
        folder = os.path.expanduser(folder)
        if os.path.isdir(folder):
            return folder
    return os.getcwd()

def handle_qr_make(text):
    try:
        matrix = make_qr(text)
    except ValueError as e:
        print("Bob:", e)
        return
    width = len(matrix) + 4
    if width <= shutil.get_terminal_size((40, 20)).columns:
        print()
        for line in qr_lines(matrix):
            print(line)
        print()
    else:
        print(f"Bob: That code is {width} characters wide, too wide for this screen, so I'm only saving the image.")
    base = os.path.join(qr_save_dir(), f"bob_qr_{datetime.datetime.now():%Y%m%d_%H%M%S}")
    path, n = base + ".png", 1
    while os.path.exists(path):  # never overwrite an earlier code made in the same second
        n += 1
        path = f"{base}_{n}.png"
    try:
        write_qr_png(matrix, path)
        print(f"Bob: Saved the image: {path}")
    except OSError:
        print("Bob: I couldn't save the image in this folder.")
    print("     (Scan it with your camera. On a light-colored screen the on-screen code can look inverted; "
          "use the saved image then.)")

def handle_qr_wifi(rest):
    try:
        parts = shlex.split(rest)
    except ValueError:
        parts = []
    if not parts or len(parts) > 2:
        print('Bob: Try: qr wifi "My Network" mypassword   (leave off the password for an open network)')
        return
    esc = lambda s: re.sub(r'([\\;,:"])', r"\\\1", s)
    if len(parts) == 2:
        payload = f"WIFI:T:WPA;S:{esc(parts[0])};P:{esc(parts[1])};;"
    else:
        payload = f"WIFI:T:nopass;S:{esc(parts[0])};;"
    handle_qr_make(payload)

def decode_qr_image(path):
    """Return the text in a QR code image. Raises ValueError with a friendly message."""
    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        raise ValueError(f"I can't find the image '{path}'. Check the name and the folder.")
    if not path.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".webp")):
        raise ValueError("I can read .png, .jpg, .jpeg, .bmp, or .webp images.")
    available = False
    try:  # 1) OpenCV
        import cv2
        available = True
        img = cv2.imread(path)
        if img is None:
            raise ValueError("I couldn't open that image. It may be damaged.")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        resize = lambda f: cv2.resize(gray, None, fx=f, fy=f, interpolation=cv2.INTER_CUBIC if f > 1 else cv2.INTER_AREA)
        variants = [img, gray, resize(2), resize(1.5), cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]]
        if max(gray.shape) > 1200:  # big phone photos: also try smaller copies
            variants += [resize(0.5), resize(0.25)]
        detectors = [cv2.QRCodeDetector()]
        if hasattr(cv2, "QRCodeDetectorAruco"):  # a second, different algorithm in newer OpenCV versions
            detectors.append(cv2.QRCodeDetectorAruco())
        for detector in detectors:
            for variant in variants:
                try:
                    text = detector.detectAndDecode(variant)[0]
                except Exception:
                    continue
                if text:
                    return text
    except ImportError:
        pass
    try:  # 2) pyzbar
        from pyzbar.pyzbar import decode as zbar_decode
        from PIL import Image
        available = True
        for item in zbar_decode(Image.open(path)):
            if item.type == "QRCODE":
                return item.data.decode("utf-8", "replace")
    except ImportError:
        pass
    except Exception:
        pass
    exe = shutil.which("zbarimg")  # 3) the zbarimg command-line tool
    if exe:
        available = True
        try:
            out = subprocess.run([exe, "-q", "--raw", path], capture_output=True, text=True, timeout=20).stdout.strip()
            if out:
                return out
        except Exception:
            pass
    if not available:
        raise ValueError("To read QR codes I need a decoder: OpenCV (pip install opencv-python-headless), "
                         "pyzbar, or the zbarimg tool. These can be hard to install on a phone; if so, use a PC "
                         "or Google Colab for reading. I can still make QR codes anywhere.")
    raise ValueError("I couldn't find a readable QR code in that image. Try a closer, brighter, straighter "
                     "picture with the whole code in view.")

def latest_image():
    """The newest picture in the usual phone folders (Termux needs termux-setup-storage once)."""
    newest, seen = None, 0
    for folder in ("~/storage/dcim", "~/storage/pictures", "~/storage/downloads", "/storage/emulated/0/DCIM",
                   "/storage/emulated/0/Pictures", "/storage/emulated/0/Download"):
        for root, dirs, files in os.walk(os.path.expanduser(folder)):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for name in files:
                if name.lower().endswith((".jpg", ".jpeg", ".png", ".webp", ".bmp")) and seen < 5000:
                    seen += 1
                    full = os.path.join(root, name)
                    try:
                        mtime = os.path.getmtime(full)
                    except OSError:
                        continue
                    if newest is None or mtime > newest[0]:
                        newest = (mtime, full)
    return newest[1] if newest else None

def describe_qr(text):
    t = text.strip()
    low = t.lower()
    if re.match(r"https?://", low):
        return ("That's a web link. QR links can lead to fake sites, so check it before you open it. "
                "I won't open it myself. (To have me read the page, say: read <the link>)")
    if low.startswith("wifi:"):
        fields = {k: re.sub(r"\\(.)", r"\1", v) for k, v in re.findall(r"(?:^|;)([A-Z]):((?:\\.|[^;])*)", t[5:])}
        security = fields.get("T", "")
        security = "none (open network)" if security in ("", "nopass") else security
        return (f"That's a Wi-Fi code: network '{fields.get('S', '?')}', security {security}, "
                f"password {fields.get('P') or '(none)'}.")
    if low.startswith(("upi:", "bitcoin:", "ethereum:", "paypal.me")):
        return "That looks like a payment request. Don't pay unless you know exactly who it's for."
    if low.startswith("begin:vcard"):
        return "That's a contact card."
    if low.startswith(("mailto:", "tel:", "sms:", "geo:")):
        return f"That's a {low.split(':')[0]} code."
    return "That's plain text."

def handle_qr_read(path):
    path = path.strip().strip("'\"")
    if not path:
        path = latest_image()
        if not path:
            print("Bob: Tell me which image, like: scan qr /storage/emulated/0/DCIM/Camera/photo.jpg  "
                  "(Termux users: run termux-setup-storage once first.)")
            return
        print(f"Bob: Reading your newest image: {path}")
    try:
        text = decode_qr_image(path)
    except ValueError as e:
        print("Bob:", e)
        return
    print(f"Bob: The QR code says: {text}")
    print("     " + describe_qr(text))

# =====================================================================
# LEARNING FROM YOU: two kinds of feedback
#   - good/bad reply  -> Bob picks the replies you like more often
#   - wrong topic     -> Bob adds your message to his data and retrains
# =====================================================================
def pick_reply(intent):
    options = replies.get(intent) or ["I'm not sure what to say to that yet. Try teaching me!"]
    if random.random() < 0.2:
        return random.choice(options)  # explore: sometimes try something different
    scores = feedback.get(intent, {})
    best = max(scores.get(r, 0) for r in options)
    return random.choice([r for r in options if scores.get(r, 0) == best])  # exploit what works

def record_feedback(intent, reply, delta):
    feedback.setdefault(intent, {})
    feedback[intent][reply] = feedback[intent].get(reply, 0) + delta
    save_json(FEEDBACK_FILE, feedback)

def teach(msg):
    global vec, model
    print("Bob: Teach me! Which category fits?")
    print("     " + ", ".join(sorted(data.keys())) + "  (or type 'skip')")
    label = input("You: ").strip().lower()
    if label in data:
        data[label].append(msg)                      # new training example
        learned.setdefault(label, []).append(msg)
        save_json(LEARNED_FILE, learned)             # keep it for next time
        vec, model = train()                         # RETRAIN with the new data
        print(f"Bob: Got it! '{msg}' now counts as '{label}'. I just retrained.")
    else:
        print("Bob: Okay, skipped.")

# =====================================================================
# CHAT LOOP
# =====================================================================
ask_feedback = True

if user_name:
    print(f"Bob: Welcome back, {user_name}! Type 'quit' to leave.")
else:
    print("Bob: Hi, I'm Bob. Tell me your name with 'my name is ...'. Type 'quit' to leave.")
print("     Try: who is Ada Lovelace | what is 15% of 240 | weather in paris | 100 usd to eur | read <link> | web <question> | qr <text>")

try:
    while True:
        raw = input("You: ").strip()  # original capitalization, needed for links and file names
        msg = raw.lower().replace("\u2019", "'")  # phone keyboards use curly '
        if msg == "quit":
            print("Bob: Bye!")
            break
        if not msg:
            continue

        if CRISIS.search(msg):  # safety first: no tools, no jokes, no rating prompt
            print(CRISIS_REPLY)
            continue

        if msg in ("feedback off", "feedback on"):
            ask_feedback = msg.endswith("on")
            print(f"Bob: Feedback prompts are {'on' if ask_feedback else 'off'}.")
            continue

        # Rule: catch "my name is X" and store it
        if msg.startswith("my name is "):
            user_name = msg.replace("my name is ", "", 1).strip().title()
            history.append(msg)
            save_memory()
            print(f"Bob: Nice to meet you, {user_name}! I'll remember that.")
            continue

        # Rule: catch "my city is X" and store it for weather questions
        if msg.startswith("my city is "):
            home_city = msg.replace("my city is ", "", 1).strip()
            history.append(msg)
            save_memory()
            print(f"Bob: Got it, your city is {home_city.title()}. Ask me 'weather' any time.")
            continue

        setkey = re.match(r"(?i)^web\s+(?:setkey|set\s+key)(?:\s+(\S+))?(?:\s+(\S+))?\s*$", raw)
        if setkey:  # keys are never added to his memory file
            first, second = setkey.group(1), setkey.group(2)
            if first and second and first.lower() in PROVIDERS:
                save_search_key(first.lower(), second)
            elif first and not second and guess_provider(clean_key(first)):
                guess = guess_provider(clean_key(first))
                print(f"Bob: That key looks like a {PROVIDERS[guess]['label']} key.")
                save_search_key(guess, first)
            else:
                print("Bob: Type: web setkey <tavily|serper|exa|brave> <your key>   "
                      "(free keys: app.tavily.com, serper.dev, exa.ai)")
            continue

        use = re.match(r"(?i)^web\s+use\b\s*(.*)$", raw)
        if use:  # 'web use' is always a setting, never a search
            words = use.group(1).lower().split()
            name = words[0] if len(words) == 1 else ""
            if name in PROVIDERS and get_key(name)[0]:
                write_key_file("_prefer", name)
                print(f"Bob: I'll try {PROVIDERS[name]['label']} first from now on.")
            else:
                have = ", ".join(p for p in PROVIDERS if get_key(p)[0]) or "none yet (add one with: web setkey <name> <key>)"
                print(f"Bob: Type just the service name, like: web use serper   Services with a key: {have}")
            continue

        if msg in ("web status", "web key", "web check"):
            web_status()
            history.append(msg)
            save_memory()
            continue

        # Reading: links, files, and follow-up commands about the page Bob is reading
        web_match = re.match(r"(?i)^(?:web search|web|google|search the web for|search web for|search online for|look online for)\s+(.+)$", raw)
        qr_read = re.match(r"(?i)^(?:read|scan|decode)\s+(?:a\s+|the\s+|my\s+)?qr(?:\s*code)?"
                           r"(?:\s+(?:from\s+|in\s+|of\s+)?(\S.*\.(?:png|jpe?g|bmp|webp)))?\s*$", raw)
        qr_wifi = re.match(r"(?i)^(?:(?:make|create|generate)\s+(?:me\s+)?(?:a\s+)?)?qr(?:\s*code)?\s+wifi\s+(.+)$", raw)
        qr_make = re.match(r"(?i)^(?:(?:make|create|generate)\s+(?:me\s+)?(?:a\s+)?)?qr(?:\s*code)?"
                           r"(?:\s+(?:for|of))?\s+(.+)$", raw)
        if qr_make and qr_make.group(1).lower().startswith(("code", "read ", "scan ", "decode ")):
            qr_make = None  # "qr codes are cool" and "make me a qr code" are chat, not commands
        qr_cmd = qr_read or qr_wifi or qr_make
        url = None if (web_match or qr_cmd) else re.search(r"https?://\S+", raw)
        file_match = re.match(r"(?i)^(?:read|open|summari[sz]e)(?:\s+file)?\s+['\"]?(.+?\.(?:txt|md|html?|pdf))['\"]?$", raw)
        if qr_cmd or web_match or url or file_match or msg in ("summary", "summarize", "summarise", "summarize it", "tldr", "save notes") \
                or (doc and (msg.startswith("find ") or msg.startswith("what does it say about ") or msg == "save")):
            if qr_read:
                handle_qr_read(qr_read.group(1) or "")
            elif qr_wifi:
                handle_qr_wifi(qr_wifi.group(1))
            elif qr_make:
                handle_qr_make(qr_make.group(1).strip())
            elif web_match:
                handle_web(web_match.group(1).strip())
            elif url:
                handle_read(url.group(0).rstrip(".,;)'\""))
            elif file_match:
                handle_read(file_match.group(1))
            elif msg == "save notes" or msg == "save":
                handle_save()
            elif msg.startswith(("find ", "what does it say about ")):
                handle_find(re.sub(r"^(find|what does it say about)\s+", "", msg))
            else:
                handle_summary()
            history.append("[qr request, not saved]" if qr_cmd else msg)  # codes can hold passwords
            save_memory()
            continue

        # Perceive: fix typos, then ask: what kind of message is this? is it clean math?
        fixed = fix_spelling(msg)
        intent, conf, understood = classify(msg, fixed)
        intent, confident = refine(intent, conf, understood)
        math_answer = calculate(msg)
        if math_answer is None and fixed != msg:
            math_answer = calculate(fixed)
            if math_answer is not None:
                understood = fixed
        if understood != msg and (confident or math_answer is not None):
            print(f'     (I read that as: "{understood}")')

        # DECISION: lookup if he's sure it's a fact question, or if he's unsure but it
        # looks like a question (better to check than to guess).
        tool = None if math_answer is not None else pick_live_tool(intent, confident, understood)
        wants_lookup = ((confident and intent == "lookup") or (not confident and looks_like_question(understood))
                        or (tool is None and confident and intent in LIVE_INTENTS))

        if math_answer is not None:  # TOOL: calculator
            if math_answer == "undefined":
                print("Bob: That's undefined. You can't divide by zero.")
            else:
                print(f"Bob: {math_answer}  (I used my calculator, not a guess)")
        elif tool == "weather":      # TOOL: Open-Meteo
            handle_weather(understood)
        elif tool == "currency":     # TOOL: Frankfurter
            handle_currency(understood)
        elif tool == "news":         # TOOL: RSS headlines
            handle_news(understood)
        elif wants_lookup and any(w in msg or w in understood for w in UNSUPPORTED_LIVE):
            print("Bob: I can't check that live. I can do weather, currency rates, and news headlines, "
                  "plus Wikipedia for facts that don't change by the minute.")
        elif wants_lookup:           # TOOL: Wikipedia
            topic = extract_topic(msg)
            print(f"Bob: Let me look that up: {topic}...")
            result = lookup_with_spellcheck(topic)
            if result:
                title, summary, corrected = result
                if corrected and corrected.lower() != topic.lower():
                    print(f"Bob: Showing results for '{corrected}' (you typed '{topic}').")
                print(f"Bob: {summary} (Source: Wikipedia, '{title}')")
            else:
                print("Bob: I found nothing. Either I'm offline or there's no match. "
                      "I'd rather admit that than guess. (Try: web <your question>)")
        elif not confident:          # unsure: ask to be taught instead of guessing
            print("Bob: I don't understand that yet.")
            teach(msg)
        elif intent == "my_name":
            print(f"Bob: You're {user_name}!" if user_name else "Bob: You haven't told me yet. Say 'my name is ...'.")
        elif intent == "recall":
            print(f"Bob: You said: '{history[-1]}'" if history else "Bob: You haven't said anything yet.")
        else:                        # his own trained reply, then ask how it went
            reply = pick_reply(intent)
            print("Bob:", reply)
            if ask_feedback:
                rating = input("     Rate: g = good, b = bad reply, w = wrong topic, Enter = skip: ").strip().lower()
                if rating == "g":
                    record_feedback(intent, reply, 1)
                    print("Bob: Noted. I'll use replies like that more.")
                elif rating == "b":
                    record_feedback(intent, reply, -1)
                    print("Bob: Noted. I'll try other replies.")
                elif rating == "w":
                    teach(msg)

        history.append(msg)  # remember this message
        save_memory()
except (KeyboardInterrupt, EOFError):
    print("\nBob: Bye!")
