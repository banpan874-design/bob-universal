#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
echo "== Bob Universal: Termux setup =="
pkg update
pkg install python python-numpy -y
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python - <<'PY'
import numpy, sklearn
print('Dependencies OK. NumPy:', numpy.__version__, '| scikit-learn:', sklearn.__version__)
PY
echo "Setup complete. Start Bob with: bash start.sh"
